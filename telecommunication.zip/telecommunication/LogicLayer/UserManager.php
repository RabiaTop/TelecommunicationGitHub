<?php 
	require_once("/DataLayer/DB.php");//C:\wamp64\www\\telecommunication
	require_once("Users.php");
	
	class UserManager {
		
		public static function getAllUsers () {
			$db = new DB();
			$result = $db->getDataTable("select tc_no,user_name, user_surname,user_password, e_mail,user_add,user_delete,user_edit from users order by user_name");
			
			$allUsers = array();
			
			while($row = $result->fetch_assoc()) {
				$userObj = new User($row["tc_no"],$row["user_name"], $row["user_surname"],$row["user_password"], $row["e_mail"],$row["user_add"],$row["user_delete"],$row["user_edit"]);
				array_push($allUsers, $userObj);
			}
			
			return $allUsers;
		}
		
		public static function insertNewUser($tc_no,$user_name,$user_surname, $user_password,$e_mail,$user_add,$user_delete,$user_edit) {
			$db = new DB();
			$success = $db->executeQuery("INSERT INTO users(tc_no, user_name, user_surname,user_password,e_mail,user_add,user_delete,user_edit) VALUES ('$tc_no', '$user_name', '$user_surname', '$user_password', '$e_mail',$user_add,$user_delete,$user_edit)");
			return $success;
		}
		
		public static function deleteUser($tc_no) {
			$db = new DB();
			$success = $db->executeQuery("DELETE FROM users WHERE tc_no='$tc_no'");
			return $success;
		}
	}
?>