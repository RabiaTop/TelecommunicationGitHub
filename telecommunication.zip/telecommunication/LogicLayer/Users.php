<?php 
	class User {
	
		private $tc_no;
		private $user_name;
		private $user_surname;
		private $user_password;		
		private $e_mail;
		private $user_add;
		private $user_delete;
		private $user_edit;
		
		function __construct($tc_no = NULL, $user_name= NULL,$user_surname = NULL,$user_password=NULL,$e_mail=NULL,$user_add=NULL,$user_delete=NULL,$user_edit) {
			
			$this->tc_no = $tc_no;
			$this->user_name = $user_name;
			$this->user_surname = $user_surname;
			$this->user_password = $user_password;
			$this->e_mail = $e_mail;
			$this->user_add = $user_add;
			$this->user_delete = $user_delete;
			$this->user_edit = $user_edit;
		}
		
	
		
		public function getTc_no() {
			return $this->tc_no;
		}
		
		public function getUser_name() {
			return $this->user_name;	
		}
		public function getUser_surname() {
			return $this->user_surname;	
		}
		public function getUser_password() {
			return $this->user_password;	
		}
		public function getE_mail() {
			return $this->e_mail;
		}
		public function getUser_add() {
			return $this->user_add;	
		}
		public function getUser_delete() {
			return $this->user_delete;	
		}
		public function getUser_edit() {
			return $this->user_edit;	
		}
	}
?>