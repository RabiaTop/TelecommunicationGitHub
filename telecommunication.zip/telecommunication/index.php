<?php 
	
	if(!isset($_GET['page'])) {
		require_once("PresentationLayer/Home/index.php");
	}
	else if($_GET['page'] == "Admin") {
		require_once("PresentationLayer/AdminPanel/home.php");
	}
	
	else if($_GET['page'] == "editUser") {
		require_once("PresentationLayer/AdminPanel/EditUser.php");
	}
		else if($_GET['page'] == "deleteUser") {
		require_once("PresentationLayer/AdminPanel/DeleteUser.php");
	}
	else if($_GET['page'] == "addUser") {
		require_once("PresentationLayer/AdminPanel/AddUser.php");
	}
	
?>
