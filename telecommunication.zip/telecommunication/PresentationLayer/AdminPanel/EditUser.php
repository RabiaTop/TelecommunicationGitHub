<?php 
	require_once("/LogicLayer/UserManager.php");
	
?>

<?php 
	include 'header.php';
	include 'slidebar.php';
?>






			    <!-- jQuery -->
    <script src="PresentationLayer/AdminPanel/vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="PresentationLayer/AdminPanel/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="PresentationLayer/AdminPanel/vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="PresentationLayer/AdminPanel/vendor/raphael/raphael.min.js"></script>
    <script src="PresentationLayer/AdminPanel/vendor/morrisjs/morris.min.js"></script>
    <script src="PresentationLayer/AdminPanel/data/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="PresentationLayer/AdminPanel/dist/js/sb-admin-2.js"></script>