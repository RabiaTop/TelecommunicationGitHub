<?php 
	require_once("/LogicLayer/UserManager.php");
	

	$errorMeesage = "";
	
	
	if(isset($_POST["tc_no"]) && isset($_POST["user_name"])&&isset($_POST["user_surname"])&& isset($_POST["user_password"])&& isset($_POST["e_mail"])&& isset($_POST["user_add"])&& isset($_POST["user_delete"])&& isset($_POST["user_edit"]) ) {
		$tc_no = trim($_POST["tc_no"]);
		$user_name = trim($_POST["user_name"]);
		$user_surname = trim($_POST["user_surname"]);
		$user_password = trim($_POST["user_password"]);
		$e_mail = trim($_POST["e_mail"]);
		$user_add = trim($_POST["user_add"]);
		$user_delete = trim($_POST["user_delete"]);
		$user_edit = trim($_POST["user_edit"]);
		
		$errorMeesage = "";
		$userManager = new UserManager();
		//echo "";
		$result = UserManager::insertNewUser($tc_no, $user_name,$user_surname,$user_password,$e_mail,$user_add,$user_delete,$user_edit);
		if(!$result) {
			$errorMeesage = "Yeni kullanıcı kaydı başarısız!";
		}
	}
	include 'header.php';
	include 'slidebar.php';
?>

	 <div id="dvMain">
		
			<form method="POST" action="<?php $_PHP_SELF ?>">
				
					
				 <div id="page-wrapper">
						<div class="container-fluid">
							<div class="row">
							<form role="form">
								
									<h1 class="page-header">
							<div class="row">
								<div class="col-md-6">
								 <div class="form-group input-group" style="width:100%">
									<input type="text" name="tc_no" class="form-control" placeholder="Tc number" required>
								 </div>
							  </div>
							   
							   

							</div>
									
							<div class="row">
								<div class="col-md-6">
								 <div class="form-group input-group" style="width:100%">
									<input type="text" name="user_name" class="form-control" placeholder="Username" required>
								 </div>
								</div>
							   
							   
								<div class="col-md-6">
								 <div class="form-group input-group" style="width:100%">
									<input type="text" name="user_surname" class="form-control" placeholder="Surname" required>
								 </div>
							  </div>
							</div>
							
							<div class="row">
								<div class="col-md-6">
								 <div class="form-group input-group" style="width:100%">
									<input type="text"name="user_password" class="form-control" placeholder="Password" required>
								 </div>
								</div>
							   
							</div>
							
							<div class="row">
								<div class="col-md-6">
								 <div class="form-group input-group" style="width:100%">
									<input type="text"name="e_mail" class="form-control" placeholder="E-mail" required>
								 </div>
								</div>
							   
							</div>
								

							<div class="row">
								<div class="col-md-4">
								 <div class="form-group input-group" style="width:100%">
									<input type="text" name="user_add" class="form-control" placeholder="User Add" required>
								 </div>
								</div>
								  <div class="col-md-4">
								 <div class="form-group input-group" style="width:100%">
									<input type="text" name="user_delete" class="form-control" placeholder="User Delete" required>
								 </div>
								</div>
								  <div class="col-md-4">
								 <div class="form-group input-group" style="width:100%">
									<input type="text" name="user_edit" class="form-control" placeholder="User Edit" required>
								 </div>
								</div>
							   
							</div>					
										  
						   <button type="submit" class="btn btn-success" style="float:right;">Success</button> 
						 </h1>
						</form> 
									
					
						
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
            </div>				
			</form>
		</div>
	</body> 

			    <!-- jQuery -->
    <script src="PresentationLayer/AdminPanel/vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="PresentationLayer/AdminPanel/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="PresentationLayer/AdminPanel/vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="PresentationLayer/AdminPanel/vendor/raphael/raphael.min.js"></script>
    <script src="PresentationLayer/AdminPanel/vendor/morrisjs/morris.min.js"></script>
    <script src="PresentationLayer/AdminPanel/data/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="PresentationLayer/AdminPanel/dist/js/sb-admin-2.js"></script>