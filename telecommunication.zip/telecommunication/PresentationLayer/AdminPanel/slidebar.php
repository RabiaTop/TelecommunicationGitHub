 <div class="navbar-default sidebar" role="navigation">
                <div class="sidebar-nav navbar-collapse">
                    <ul class="nav" id="side-menu">
                        <li class="sidebar-search">
                            <div class="input-group custom-search-form">
                                <input type="text" class="form-control" placeholder="Search...">
                                <span class="input-group-btn">
                                <button class="btn btn-default" type="button">
                                    <i class="fa fa-search"></i>
                                </button>
                            </span>
                            </div>
                            <!-- /input-group -->
                        </li>
                        <li>
                            <a href="index.php?page=Admin"><i class="fa fa-dashboard fa-fw"></i> Home</a>
                        </li>

                      
                        <li>
                            <a href="#"><i class="fa fa-wrench fa-fw"></i> Users Operation<span class="fa arrow"></span></a>
                            <ul class="nav nav-second-level">
                                <li>
                                    <a href="index.php?page=addUser">Add User</a>
                                </li>
                                <li>
                                    <a href="index.php?page=editUser">Edit User</a>
                                </li>
                                <li>
                                    <a href="index.php?page=deleteUser">Delete User</a>
                                </li>
                               
                            </ul>
                            <!-- /.nav-second-level -->
                        </li>
                 
                        
                    </ul>
                </div>
                <!-- /.sidebar-collapse -->
            </div>
			    <!-- jQuery -->
    <script src="PresentationLayer/AdminPanel/vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="PresentationLayer/AdminPanel/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="PresentationLayer/AdminPanel/vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="PresentationLayer/AdminPanel/vendor/raphael/raphael.min.js"></script>
    <script src="PresentationLayer/AdminPanel/vendor/morrisjs/morris.min.js"></script>
    <script src="PresentationLayer/AdminPanel/data/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="PresentationLayer/AdminPanel/dist/js/sb-admin-2.js"></script>