<?php 
	require_once("/LogicLayer/UserManager.php");
	
 if(isset($_POST["tc_no"]) ) {
		$tc_no = trim($_POST["tc_no"]);
		$errorMeesage = "";
		$userManager = new UserManager();
		//echo "";
		$result = UserManager::deleteUser($tc_no);
		if(!$result) {
			$errorMeesage = "Yeni kullanıcı kaydı başarısız!";
		}
	}
	include 'header.php';
	include 'slidebar.php';
?>

	 <div id="dvMain">
		
			<form method="POST" action="<?php $_PHP_SELF ?>">
				
					
				 <div id="page-wrapper">
						<div class="container-fluid">
							<div class="row">
							<form role="form">
								
									<h1 class="page-header">
							<div class="row">
								<div class="col-md-6">
								 <div class="form-group input-group" style="width:80%">
									<input type="text" name="tc_no" class="form-control" placeholder="Tc number" required>
								 </div>
							  </div>										  
						   <button type="submit" class="btn btn-success" style="float:left;" style="background-color:#a94442">Delete</button> 
						 </h1>
						</form> 
                    </div>
                    <!-- /.col-lg-12 -->
                </div>
                <!-- /.row -->
                </div>
            </div>			
		</form>		
	</div> 

			    <!-- jQuery -->
    <script src="PresentationLayer/AdminPanel/vendor/jquery/jquery.min.js"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="PresentationLayer/AdminPanel/vendor/bootstrap/js/bootstrap.min.js"></script>

    <!-- Metis Menu Plugin JavaScript -->
    <script src="PresentationLayer/AdminPanel/vendor/metisMenu/metisMenu.min.js"></script>

    <!-- Morris Charts JavaScript -->
    <script src="PresentationLayer/AdminPanel/vendor/raphael/raphael.min.js"></script>
    <script src="PresentationLayer/AdminPanel/vendor/morrisjs/morris.min.js"></script>
    <script src="PresentationLayer/AdminPanel/data/morris-data.js"></script>

    <!-- Custom Theme JavaScript -->
    <script src="PresentationLayer/AdminPanel/dist/js/sb-admin-2.js"></script>