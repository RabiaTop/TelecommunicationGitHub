<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Free Emmeline Website Template | Single :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href='http://fonts.googleapis.com/css?family=Lato:400,300,600,700,800' rel='stylesheet' type='text/css'>
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.lightbox.js"></script>
<link rel="stylesheet" type="text/css" href="css/lightbox.css" media="screen" />
  <script type="text/javascript">
    $(function() {
        $('.gallery a').lightBox();
    });
   </script>
</head>
<body>
<div class="wrap"> 
	<div class="pages-top">
	        <div class="logo">
				<a href="index.php"><img src="images/logo.png" alt=""/></a>
			 </div>
		     <div class="h_menu4"><!-- start h_menu4 -->
				<a class="toggleMenu" href="#">Menu</a>
				<ul class="nav">
					<li><a href="index.php">Anasayfa</a></li>
					<li><a href="pages.php">Pages</a>
						<ul>
							<li><a href="pages.php">Dropdown</a></li>
							<li><a href="pages.php">Structure</a></li>
							<li><a href="pages.php">People</a></li>
						</ul>
					</li>
					<li><a href="shortcodes.php">Shortcodes</a>
						<ul>
							<li><a href="shortcodes.php">CSR</a></li>
							<li><a href="shortcodes.php">Locations</a></li>
							<li><a href="shortcodes.php">PPV</a></li>
						</ul>
					</li>
					<li class="active"><a href="blog.php">Blog</a></li>
					<li><a href="portfolio.php">Portfolio</a>
						<ul>
							<li><a href="portfolio.php">Dropdown</a></li>
							<li><a href="portfolio.php">Structure</a></li>
							<li><a href="portfolio.php">People</a></li>
						</ul>
					</li>
					<li><a href="contact.php">Contact</a></li>
				</ul>
				<script type="text/javascript" src="js/nav.js"></script>
			</div><!-- end h_menu4 -->
			<div class="clear"></div>
		</div><!-- end header_main4 -->
     </div>
	 <div class="main">
	   <div class="wrap">
	 	  <div class="pages">
	 	   	<img src="images/s1.jpg" alt=""/>
	 	   	<p class="m_10">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil </p>
	 	   	<p class="m_11">Lorem ipsum dolor sit amet, consectetuer adipiscing elit, sed diam nonummy nibh euismod tincidunt ut laoreet dolore magna aliquam erat volutpat. Ut wisi enim ad minim veniam, quis nostrud exerci tation ullamcorper suscipit lobortis nisl ut aliquip ex ea commodo consequat. Duis autem vel eum iriure dolor in hendrerit in vulputate velit esse molestie consequat, vel illum dolore eu feugiat nulla facilisis at vero eros et accumsan et iusto odio dignissim qui blandit praesent luptatum zzril delenit augue duis dolore te feugait nulla facilisi. Nam liber tempor cum soluta nobis eleifend option congue nihil </p>
	 	  <div class="btn1"><a href="#">Read More</a></div>
	 	  <div class="clear"></div>
		  </div>
		</div>
	  </div>
		<div class="footer">
			<div class="wrap">
				<div class="footer-grid footer-grid1">
					<div class="f-logo">
				     <a href="index.php"><img src="images/f-logo.png" alt=""></a>
			        </div>
					<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words</p>
				</div>
				<div class="footer-grid footer-grid2">
					<h4>Contact</h4>
				    <ul>
						<li><i class="pin"> </i><div class="extra-wrap">
							<p>2321 Street name,<br> City name,Country</p>
						</div></li>
						<li><i class="phone"> </i><div class="extra-wrap">
							<p>+2321 256 652</p>
						</div></li>
						<li><i class="mail"> </i><div class="extra-wrap1">
							<p>info@comapnay name.com</p>
						</div></li>
						<li><i class="earth"> </i><div class="extra-wrap1">
							<p>info@comapnay name.com</p>
						</div></li>
					</ul>
				</div>
				<div class="footer-grid footer-grid3">
					<h4>Latest Tweets</h4>
					<div class="recent-tweet">
						<div class="recent-tweet-icon">
							<span> </span>
						</div>
						<div class="recent-tweet-info">
							<p>Ds which don't look even slightly believable. If you are going to use a passage <a href="#"> 3 Hours Ago</a></p>
						</div>
						<div class="clear"> </div>
					</div>
					<div class="recent-tweet1">
						<div class="recent-tweet-icon">
							<span> </span>
						</div>
						<div class="recent-tweet-info">
							<p>Ds which don't look even slightly believable. If you are going to use a passage <a href="#"> 3 Hours Ago</a></p>
						</div>
						<div class="clear"> </div>
					</div>
				</div>
				<div class="footer-grid footer-grid4">
					<h4>News Letter</h4>
					<p>Randomised words which don't look even slightly believable. If you are going to use a passage</p>
					<form>
						<input type="text" value="Email Address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email Address';}">
						<input type="submit" value="">
					</form>
				</div>
				<div class="clear"> </div>
			</div>
		</div>
		<div class="footer-bottom">
	 		  <div class="wrap">
	     	  	<div class="copy">
				   <p>© 2014 Template by <a href="http://w3layouts.com" target="_blank"> w3layouts</a></p>
			    </div>
			    <div class="social">	
				   <ul>	
					  <li class="facebook"><a href="#"><span> </span></a></li>
					  <li class="linkedin"><a href="#"><span> </span></a></li>
					  <li class="twitter"><a href="#"><span> </span></a></li>		
				   </ul>
			    </div>
			    <div class="clear"></div>
			  </div>
       </div>
</body>
</html>