<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Free Emmeline Website Template | Portfolio :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href='http://fonts.googleapis.com/css?family=Lato:400,300,600,700,800' rel='stylesheet' type='text/css'>
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.lightbox.js"></script>
<link rel="stylesheet" type="text/css" href="css/lightbox.css" media="screen" />
  <script type="text/javascript">
    $(function() {
        $('.gallery1 a').lightBox();
    });
   </script>
</head>
<body>
<div class="wrap"> 
	<div class="pages-top">
	        <div class="logo">
				<a href="index.php"><img src="images/logo.png" alt=""/></a>
			 </div>
		     <div class="h_menu4"><!-- start h_menu4 -->
				<a class="toggleMenu" href="#">Menu</a>
				<ul class="nav">
				    <li><a href="index.php">Anasayfa</a></li>
					<li><a href="pages.php">Giriş Yap</a>
						<ul>
							<li><a href="pages.php">Hesabım</a></li>
							<li><a href="pages.php">Street</a></li>
							<li><a href="pages.php">People</a></li>
						</ul>
					</li>
					
					<li><a href="blog.php">Kampanyalar</a></li>

					<li class="active"><a href="portfolio.php">Fatura Öde</a></li>
											
					<li><a href="contact.php">TL/Paket Yükle</a></li>
				</ul>
				<script type="text/javascript" src="js/nav.js"></script>
			</div><!-- end h_menu4 -->
			<div class="clear"></div>
		</div><!-- end header_main4 -->
     </div>
	 <div class="main">
	     <div class="wrap">
	 	   <div class="pages">
			 <div class="gallery1">
			   <ul>
				<li>
					<a href="images/p5.jpg"><img src="images/p5.jpg" alt=""/></a>
					<h3>Duis autem vel eumter</h3>
				</li>
				<li>
					<a href="images/p2.jpg"><img src="images/p2.jpg" alt=""/></a>
					<h3>uffered alteration</h3>
				</li>
				<li class="last">
					<a href="images/p6.jpg"><img src="images/p6.jpg" alt=""/></a>
					<h3>augue duis dolore te</h3>
				</li>
				<li>
					<a href="images/p4.jpg"><img src="images/p4.jpg" alt=""/></a>
					<h3>parum claram, anteposuerit</h3>
				</li>
				<li>
					<a href="images/p1.jpg"><img src="images/p1.jpg" alt=""/></a>
					<h3>seacula quarta decima</h3>
				</li>
				<li class="last">
					<a href="images/p3.jpg"><img src="images/p3.jpg" alt=""/></a>
					<h3>mutationem consuetudium </h3>
				</li>
					<li>
					<a href="images/p7.jpg"><img src="images/p7.jpg" alt=""/></a>
					<h3>eleifend option congue</h3>
				</li>
				<li>
					<a href="images/p8.jpg"><img src="images/p8.jpg" alt=""/></a>
					<h3>imperdiet doming</h3>
				</li>
				<li class="last">
					<a href="images/p9.jpg"><img src="images/p9.jpg" alt=""/></a>
					<h3>usto odio dignissim qui </h3>
				</li>
			   <div class="clear"></div>
			</ul>
		   </div>
		    <ul class="dc_pagination dc_paginationA dc_paginationA06">
			  <li><a href="#" class="previous">Previous</a></li>
			  <li><a href="#">1</a></li>
			  <li><a href="#" class="current">2</a></li>
			  <li><a href="#">3</a></li>
			  <li><a href="#">4</a></li>
			  <li><a href="#">5</a></li>
			  <li><a href="#">...</a></li>
			  <li><a href="#">19</a></li>
			  <li><a href="#">20</a></li>
			  <li><a href="#" class="next">Next</a></li>
		     </ul>
		    </div>
            <div class="clear"></div>	
		  </div>
		</div>
		<div class="footer">
			<div class="wrap">
				<div class="footer-grid footer-grid1">
					<div class="f-logo">
				     <a href="index.php"><img src="images/f-logo.png" alt=""></a>
			        </div>
					<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words</p>
				</div>
				<div class="footer-grid footer-grid2">
					<h4>Contact</h4>
				    <ul>
						<li><i class="pin"> </i><div class="extra-wrap">
							<p>2321 Street name,<br> City name,Country</p>
						</div></li>
						<li><i class="phone"> </i><div class="extra-wrap">
							<p>+2321 256 652</p>
						</div></li>
						<li><i class="mail"> </i><div class="extra-wrap1">
							<p>info@comapnay name.com</p>
						</div></li>
						<li><i class="earth"> </i><div class="extra-wrap1">
							<p>info@comapnay name.com</p>
						</div></li>
					</ul>
				</div>
				<div class="footer-grid footer-grid3">
					<h4>Latest Tweets</h4>
					<div class="recent-tweet">
						<div class="recent-tweet-icon">
							<span> </span>
						</div>
						<div class="recent-tweet-info">
							<p>Ds which don't look even slightly believable. If you are going to use a passage <a href="#"> 3 Hours Ago</a></p>
						</div>
						<div class="clear"> </div>
					</div>
					<div class="recent-tweet1">
						<div class="recent-tweet-icon">
							<span> </span>
						</div>
						<div class="recent-tweet-info">
							<p>Ds which don't look even slightly believable. If you are going to use a passage <a href="#"> 3 Hours Ago</a></p>
						</div>
						<div class="clear"> </div>
					</div>
				</div>
				<div class="footer-grid footer-grid4">
					<h4>News Letter</h4>
					<p>Randomised words which don't look even slightly believable. If you are going to use a passage</p>
					<form>
						<input type="text" value="Email Address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email Address';}">
						<input type="submit" value="">
					</form>
				</div>
				<div class="clear"> </div>
			</div>
		</div>
		<div class="footer-bottom">
	 		  <div class="wrap">
	     	  	<div class="copy">
				   <p>© 2014 Template by <a href="http://w3layouts.com" target="_blank"> w3layouts</a></p>
			    </div>
			    <div class="social">	
				   <ul>	
					  <li class="facebook"><a href="#"><span> </span></a></li>
					  <li class="linkedin"><a href="#"><span> </span></a></li>
					  <li class="twitter"><a href="#"><span> </span></a></li>		
				   </ul>
			    </div>
			    <div class="clear"></div>
			  </div>
       </div>
</body>
</html>