<!--A Design by W3layouts
Author: W3layout
Author URL: http://w3layouts.com
License: Creative Commons Attribution 3.0 Unported
License URL: http://creativecommons.org/licenses/by/3.0/
-->
<!DOCTYPE HTML>
<html>
<head>
<title>Free Emmeline Website Template | Blog :: w3layouts</title>
<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link href="css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href='http://fonts.googleapis.com/css?family=Lato:400,300,600,700,800' rel='stylesheet' type='text/css'>
<script src="js/jquery.min.js"></script>
<script type="text/javascript" src="js/jquery.lightbox.js"></script>
<link rel="stylesheet" type="text/css" href="css/lightbox.css" media="screen" />
  <script type="text/javascript">
    $(function() {
        $('.gallery a').lightBox();
    });
   </script>
</head>
<body>
<div class="wrap"> 
	<div class="pages-top">
	        <div class="logo">
				<a href="index.php"><img src="images/logo.png" alt=""/></a>
			 </div>
		     <div class="h_menu4"><!-- start h_menu4 -->
				<a class="toggleMenu" href="#">Menu</a>
				<ul class="nav">
					<li><a href="index.php">Anasayfa</a></li>
					<li><a href="pages.php">Giriş Yap</a>
						<ul>
							<li><a href="pages.php">Hesabım</a></li>
							<li><a href="pages.php">Street</a></li>
							<li><a href="pages.php">People</a></li>
						</ul>
					</li>
					
					<li class="active"><a href="blog.php">Kampanyalar</a></li>

					<li><a href="portfolio.php">Fatura Öde</a></li>
											
					<li><a href="contact.php">TL/Paket Yükle</a></li>
				</ul>
				<script type="text/javascript" src="js/nav.js"></script>
			</div><!-- end h_menu4 -->
			<div class="clear"></div>
		</div><!-- end header_main4 -->
     </div>
	 <div class="main">
	     <div class="wrap">
	 	   <div class="pages">
	 	   	 <div class="blog-top">
			  <div class="col_1_of_b span_1_of_b">
					<h3><a href="single.php">Kampanya-1</a></h3>
					<a href="single.php"><img src="images/kampanya1.jpg"  style="width:609px" alt=""></a>
					
					<div class="blog-poast-info">
						<ul>
							<li><i class="admin"> </i><a class="admin" href="#"><span> </span> Admin </a></li>
							<li><i class="date"> </i><a class="p-date" href="#"><span> </span>12-04-2014 </a></li>
							<li><i class="comment"> </i><a class="p-blog" href="#"><span> </span>No Comments</a></li>
						</ul>
				    </div>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					<div class="button"><a href="#">Read More</a></div>
				</div>
				<div class="col_1_of_b span_1_of_b">
					<h3><a href="single.php">Kampanya-2</a></h3>
					<a href="single.php"><img src="images/kampanya2.jpg" style="width:609px" alt=""></a>
					
					<div class="blog-poast-info">
						<ul>
							<li><i class="admin"> </i><a class="admin" href="#"><span> </span> Admin </a></li>
							<li><i class="date"> </i><a class="p-date" href="#"><span> </span>12-04-2014 </a></li>
							<li><i class="comment"> </i><a class="p-blog" href="#"><span> </span>No Comments</a></li>
						</ul>
				    </div>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					<div class="button"><a href="#">Read More</a></div>
				</div>
				<div class="clear"></div>
			  </div>
			  <div class="blog-top">
			  <div class="col_1_of_b span_1_of_b">
					<h3><a href="single.php">Kampanya-3</a></h3>
					<a href="single.php"><img src="images/kampanya3.jpg" style="width:609px" alt=""></a>
					
					<div class="blog-poast-info">
						<ul>
							<li><i class="admin"> </i><a class="admin" href="#"><span> </span> Admin </a></li>
							<li><i class="date"> </i><a class="p-date" href="#"><span> </span>12-04-2014 </a></li>
							<li><i class="comment"> </i><a class="p-blog" href="#"><span> </span>No Comments</a></li>
						</ul>
				    </div>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					<div class="button"><a href="#">Read More</a></div>
				</div>
				<div class="col_1_of_b span_1_of_b">
					<h3><a href="single.php">Kampanya-4</a></h3>
					<a href="single.php"><img src="images/kampanya4.jpg" style="width:609px" alt=""></a>
					
					<div class="blog-poast-info">
						<ul>
							<li><i class="admin"> </i><a class="admin" href="#"><span> </span> Admin </a></li>
							<li><i class="date"> </i><a class="p-date" href="#"><span> </span>12-04-2014 </a></li>
							<li><i class="comment"> </i><a class="p-blog" href="#"><span> </span>No Comments</a></li>
						</ul>
				    </div>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					<div class="button"><a href="#">Read More</a></div>
				</div>
				<div class="clear"></div>
			  </div>
			  <div class="blog-top">
			  <div class="col_1_of_b span_1_of_b">
					<h3><a href="single.php">Kampanya-5</a></h3>
					<a href="single.php"><img src="images/kampanya5.jpg" style="width:609px" alt=""></a>
					
					<div class="blog-poast-info">
						<ul>
							<li><i class="admin"> </i><a class="admin" href="#"><span> </span> Admin </a></li>
							<li><i class="date"> </i><a class="p-date" href="#"><span> </span>12-04-2014 </a></li>
							<li><i class="comment"> </i><a class="p-blog" href="#"><span> </span>No Comments</a></li>
						</ul>
				    </div>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					<div class="button"><a href="#">Read More</a></div>
				</div>
				<div class="col_1_of_b span_1_of_b">
					<h3><a href="single.php">Kampanya-6</a></h3>
					<a href="single.php"><img src="images/kampanya6.jpg" style="width:609px" alt=""></a>
					<div class="blog-poast-info">
						<ul>
							<li><i class="admin"> </i><a class="admin" href="#"><span> </span> Admin </a></li>
							<li><i class="date"> </i><a class="p-date" href="#"><span> </span>12-04-2014 </a></li>
							<li><i class="comment"> </i><a class="p-blog" href="#"><span> </span>No Comments</a></li>
						</ul>
				    </div>
					<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
					<div class="button"><a href="#">Read More</a></div>
				</div>
				<div class="clear"></div>
			  </div>
		     </div>
		  </div>
		</div>
		<div class="footer">
			<div class="wrap">
				<div class="footer-grid footer-grid1">
					<div class="f-logo">
				     <a href="index.php"><img src="images/f-logo.png" alt=""></a>
			        </div>
					<p>There are many variations of passages of Lorem Ipsum available, but the majority have suffered alteration in some form, by injected humour, or randomised words</p>
				</div>
				<div class="footer-grid footer-grid2">
					<h4>Contact</h4>
				    <ul>
						<li><i class="pin"> </i><div class="extra-wrap">
							<p>2321 Street name,<br> City name,Country</p>
						</div></li>
						<li><i class="phone"> </i><div class="extra-wrap">
							<p>+2321 256 652</p>
						</div></li>
						<li><i class="mail"> </i><div class="extra-wrap1">
							<p>info@comapnay name.com</p>
						</div></li>
						<li><i class="earth"> </i><div class="extra-wrap1">
							<p>info@comapnay name.com</p>
						</div></li>
					</ul>
				</div>
				<div class="footer-grid footer-grid3">
					<h4>Latest Tweets</h4>
					<div class="recent-tweet">
						<div class="recent-tweet-icon">
							<span> </span>
						</div>
						<div class="recent-tweet-info">
							<p>Ds which don't look even slightly believable. If you are going to use a passage <a href="#"> 3 Hours Ago</a></p>
						</div>
						<div class="clear"> </div>
					</div>
					<div class="recent-tweet1">
						<div class="recent-tweet-icon">
							<span> </span>
						</div>
						<div class="recent-tweet-info">
							<p>Ds which don't look even slightly believable. If you are going to use a passage <a href="#"> 3 Hours Ago</a></p>
						</div>
						<div class="clear"> </div>
					</div>
				</div>
				<div class="footer-grid footer-grid4">
					<h4>News Letter</h4>
					<p>Randomised words which don't look even slightly believable. If you are going to use a passage</p>
					<form>
						<input type="text" value="Email Address" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email Address';}">
						<input type="submit" value="">
					</form>
				</div>
				<div class="clear"> </div>
			</div>
		</div>
		<div class="footer-bottom">
	 		  <div class="wrap">
	     	  	<div class="copy">
				   <p>© 2014 Template by <a href="http://w3layouts.com" target="_blank"> w3layouts</a></p>
			    </div>
			    <div class="social">	
				   <ul>	
					  <li class="facebook"><a href="#"><span> </span></a></li>
					  <li class="linkedin"><a href="#"><span> </span></a></li>
					  <li class="twitter"><a href="#"><span> </span></a></li>		
				   </ul>
			    </div>
			    <div class="clear"></div>
			  </div>
       </div>
</body>
</html>